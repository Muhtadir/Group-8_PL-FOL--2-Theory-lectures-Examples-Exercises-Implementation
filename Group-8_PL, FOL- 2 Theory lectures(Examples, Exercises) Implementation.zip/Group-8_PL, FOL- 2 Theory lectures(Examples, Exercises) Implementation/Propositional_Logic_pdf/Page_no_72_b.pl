% Everyone loves his/her mother.
mother(X,Y)

loves(Y,X) :- mother(X,Y).