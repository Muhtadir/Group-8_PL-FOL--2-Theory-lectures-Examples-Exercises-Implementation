% Some birds cannot fly.
bird(X).
bird_that_is_unable_to_fly(X).

not(fly(X)) :- bird(X),bird_that_is_unable_to_fly(X).


