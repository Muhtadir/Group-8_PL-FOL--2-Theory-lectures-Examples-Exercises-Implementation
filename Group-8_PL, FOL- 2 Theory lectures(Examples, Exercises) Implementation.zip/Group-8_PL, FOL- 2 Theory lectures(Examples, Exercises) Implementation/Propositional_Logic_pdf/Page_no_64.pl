% Mammals drink milk.
% Man is mortal.
% Man is mammal.
% Tom is a man.

mammal(X).
drink(X,milk).
man(X).
man(tom).

drink(X,milk) :- mammal(X).
mortal(X) :- man(X).
mammal(X) :- man(X).