% All dogs have four lags.
dog(X).

has_legs(X,4) :- dog(X).