% It rains in July
% The book is not costly
% If it rains today and one does not carry umbrella then he will be drenched

rain(today).
not(carry(X,umbrella)).

drenhced(X) :- rain(today),not(carry(X,umbrella)).
