% If AB and AC are equal then angle B and C are equal
equal(ab,ac).

equal(b,c) :- equal(ab,ac).