% ABC is an equilateral triangle.
triangle(abc).

equilateral(abc) :- triangle(abc).