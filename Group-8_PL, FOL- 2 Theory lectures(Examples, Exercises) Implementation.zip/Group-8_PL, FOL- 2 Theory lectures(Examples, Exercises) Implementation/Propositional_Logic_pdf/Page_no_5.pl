%If Rahima is intelligent and Rahima is hardworking Then Rahima scores high marks.

intelligent(rahima).
hardworking(rahima).

scores_highmarks(X) :- intelligent(X),hardworking(X).