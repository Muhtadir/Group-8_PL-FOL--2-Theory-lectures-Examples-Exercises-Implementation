% Angle B is equal to angle C.

equal(b,c).