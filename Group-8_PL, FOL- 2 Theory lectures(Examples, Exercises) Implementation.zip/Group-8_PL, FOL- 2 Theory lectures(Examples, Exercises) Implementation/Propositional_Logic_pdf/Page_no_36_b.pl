% If a triangle is isosceles then two sides AB and AC are equal.
triangle(X).
isosceles(X).

equal(ab,ac) :- triangle(X),isosceles(X).
