% If a triangle is equilateral then it is isosceles.
triangle(X).
equilateral(X).

isosceles(X) :- triangle(X),equilateral(X).