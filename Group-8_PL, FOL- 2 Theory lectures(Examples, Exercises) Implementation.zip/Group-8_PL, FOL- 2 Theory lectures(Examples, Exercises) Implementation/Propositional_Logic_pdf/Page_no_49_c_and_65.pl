% At least one planet has life on it.
planet(X).
planet_that_has_life_on_it(X).

has_life(X) :- planet(X),planet_that_has_life_on_it(X).