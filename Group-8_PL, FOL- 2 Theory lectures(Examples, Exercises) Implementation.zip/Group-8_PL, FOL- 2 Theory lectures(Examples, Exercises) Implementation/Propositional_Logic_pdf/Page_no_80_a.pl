% If a perfect square is divisible by a prime P, then it is also divisible by square of P.
perfect_square(Q).
prime(P).
divisible(Q,P).

divisible(Q,P*P) :- perfect_square(Q),prime(P),divisible(Q,P).