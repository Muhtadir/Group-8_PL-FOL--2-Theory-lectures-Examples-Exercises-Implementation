% All dogs are faithful.
dog(X).

faithful(X) :- dog(X).