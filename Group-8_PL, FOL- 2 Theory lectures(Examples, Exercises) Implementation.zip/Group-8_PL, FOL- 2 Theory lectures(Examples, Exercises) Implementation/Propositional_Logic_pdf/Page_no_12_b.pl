%If the roads are wet then it rains ???
road(wet).

rain(it) :- road(wet). 