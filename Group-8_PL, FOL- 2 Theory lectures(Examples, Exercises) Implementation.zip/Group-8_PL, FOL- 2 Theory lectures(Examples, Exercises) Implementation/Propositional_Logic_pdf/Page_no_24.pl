% It is the month of July
% It rains
% If it is the month of July then it rains

month(july).
rain(it).

rain(it) :- month(july).