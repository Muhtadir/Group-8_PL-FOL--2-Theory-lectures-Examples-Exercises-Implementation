% No dogs purr.
dog(X).
purr(X).

not(purr(X)) :- dog(X).