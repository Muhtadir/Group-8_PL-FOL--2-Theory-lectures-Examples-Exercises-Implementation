% Students are people who are enrolled in courses.
people(X).
enrolled(X,Y).
course(Y).

student(X) :- people(X),enrolled(X,Y),course(Y).