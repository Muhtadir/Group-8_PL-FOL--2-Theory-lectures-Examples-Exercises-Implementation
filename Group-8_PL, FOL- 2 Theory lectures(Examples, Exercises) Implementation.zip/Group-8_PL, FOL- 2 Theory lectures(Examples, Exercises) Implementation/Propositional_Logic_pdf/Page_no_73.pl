% Any number is the successor of its predecessor.
succ(X).
pred(X).
equal(X,Y).

equal(X,succ(pred(X)).