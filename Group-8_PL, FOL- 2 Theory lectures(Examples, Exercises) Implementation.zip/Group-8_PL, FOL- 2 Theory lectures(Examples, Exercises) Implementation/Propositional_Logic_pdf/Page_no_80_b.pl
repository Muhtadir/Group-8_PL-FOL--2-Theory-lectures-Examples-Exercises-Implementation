% Every perfect square is divisible by some prime.
perfect_square(Q).
prime(P).

divisible(Q,P) :- perfect_square(Q),prime(P).


