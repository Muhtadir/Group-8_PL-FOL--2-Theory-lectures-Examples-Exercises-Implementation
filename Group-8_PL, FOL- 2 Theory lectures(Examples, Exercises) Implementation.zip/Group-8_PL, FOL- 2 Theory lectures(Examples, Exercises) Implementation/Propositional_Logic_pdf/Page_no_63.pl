% All birds cannot fly.
bird(X).

not(fly(X)) :- bird(X).