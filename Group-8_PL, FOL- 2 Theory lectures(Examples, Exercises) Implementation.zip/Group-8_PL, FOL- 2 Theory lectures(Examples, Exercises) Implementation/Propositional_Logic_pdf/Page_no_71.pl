% x celebrates birthday on date y.
person(X).
date(Y).

birthday(X,Y) :- person(X),date(Y).