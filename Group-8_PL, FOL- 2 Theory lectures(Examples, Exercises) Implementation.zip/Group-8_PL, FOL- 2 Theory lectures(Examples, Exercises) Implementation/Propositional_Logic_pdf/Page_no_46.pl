% If Karim is hardworking and Karim is intelligent Then Karim scores high marks

hardworking(karim).
intelligent(karim).

scores_high_marks(X) :- hardworking(X),intelligent(X).