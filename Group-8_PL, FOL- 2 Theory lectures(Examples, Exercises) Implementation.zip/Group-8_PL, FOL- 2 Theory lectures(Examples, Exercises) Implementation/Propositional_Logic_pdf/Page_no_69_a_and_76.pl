% Some dogs bark.
dog(X).
dog_that_barks(X).

bark(X) :- dog(X), dog_that_barks(X).
