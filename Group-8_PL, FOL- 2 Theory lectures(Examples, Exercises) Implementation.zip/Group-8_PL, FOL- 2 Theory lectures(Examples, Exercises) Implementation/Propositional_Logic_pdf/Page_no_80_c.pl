% 36 is a perfect square.
perfect_square(36).