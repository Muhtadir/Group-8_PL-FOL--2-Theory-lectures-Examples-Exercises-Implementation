% Fathers are male parents with children.
parent(X,Y).
male(X).
has_child(X).

father(X,Y) :- parent(X,Y),male(X),has_child(X).