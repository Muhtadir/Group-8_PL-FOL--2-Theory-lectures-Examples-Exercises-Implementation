% All barking dogs are irritation.
dog(X).
bark(X).

is_irritation(X) :- dog(X),bark(X).