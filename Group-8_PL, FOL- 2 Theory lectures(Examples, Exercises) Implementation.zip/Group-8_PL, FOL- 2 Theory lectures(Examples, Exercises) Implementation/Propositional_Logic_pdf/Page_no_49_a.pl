% All men are mortal.
man(X).
mortal(X).

mortal(X) :- man(X).