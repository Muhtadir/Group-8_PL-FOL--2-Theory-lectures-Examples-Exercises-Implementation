% All dogs are faithful
% Tommy is a dog
% Therefore, Tommy is faithful?????

dog(X).
dog(tommy).

faithful(tommy) :- dog(X),dog(tommy).
