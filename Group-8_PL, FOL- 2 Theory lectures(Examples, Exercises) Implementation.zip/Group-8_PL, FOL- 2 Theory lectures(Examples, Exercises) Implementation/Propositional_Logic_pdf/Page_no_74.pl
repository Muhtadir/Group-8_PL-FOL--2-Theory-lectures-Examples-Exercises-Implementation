% ∀x (succ(pred(x)= x).(Alternative representation of the problem at page no 73)
succ(X).
pred(X) = X.
equal(X,Y).

equal(X,succ(pred(X)=X).