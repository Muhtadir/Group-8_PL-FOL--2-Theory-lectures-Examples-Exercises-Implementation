%If it rains then the roads are wet.
rain(it).

road(wet) :- rain(it).