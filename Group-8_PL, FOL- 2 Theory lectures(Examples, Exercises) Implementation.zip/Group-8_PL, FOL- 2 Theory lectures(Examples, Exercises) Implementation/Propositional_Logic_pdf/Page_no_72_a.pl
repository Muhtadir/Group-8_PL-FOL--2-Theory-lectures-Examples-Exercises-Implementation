% Everyone loves (all of) his/her brothers.
brother(X,Y).

love(X,Y) :- brother(X,Y).