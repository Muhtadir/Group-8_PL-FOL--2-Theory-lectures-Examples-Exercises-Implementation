% All human are mortal. Socrates is human.
human(X).
human(socrates).

mortal(X) :- human(X).
