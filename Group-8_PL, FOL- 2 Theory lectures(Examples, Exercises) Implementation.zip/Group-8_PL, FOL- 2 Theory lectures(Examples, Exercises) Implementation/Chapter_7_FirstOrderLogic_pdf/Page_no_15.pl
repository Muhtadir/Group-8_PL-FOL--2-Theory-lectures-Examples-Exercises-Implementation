% Every gardener likes the sun.
% Not Every gardener likes the sun.
% You can fool some of the people all of the time.
% You can fool all of the people some of the time.
% You can fool all of the people at some time.
% You can not fool all of the people all of the time.
% Everyone is younger than his father

gardener(X).
time(T).
person(A).
father(X).

likes(X,sun) :- gardener(X).
likes(X,sun) :- not(gardener(X)).
can_be_fooled(X,T) :- person(A),time(T).
can_be_fooled(X,T) :- not(person(X)),not(time(T)).
younger(X,father(X)) :- person(X).

