% Evil King Jhon ruled England in 1200.
ruled(john,england).
in(2010).
evil_king(john).

evil_king(X) :- ruled(X,england),in(2010).