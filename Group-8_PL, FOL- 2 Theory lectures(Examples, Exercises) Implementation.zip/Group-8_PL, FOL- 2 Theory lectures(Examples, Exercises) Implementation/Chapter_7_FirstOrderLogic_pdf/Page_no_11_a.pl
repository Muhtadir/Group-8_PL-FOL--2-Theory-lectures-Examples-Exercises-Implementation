% All person who are parents of another person and are male, are the father of that other person.
parent(X,Y).
male(X).

father(X,Y) :- parent(X,Y),male(X).