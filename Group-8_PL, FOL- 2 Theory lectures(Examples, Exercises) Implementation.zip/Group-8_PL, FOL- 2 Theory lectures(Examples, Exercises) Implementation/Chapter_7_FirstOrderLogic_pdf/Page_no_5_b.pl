% Squares neighbouring the wumpus are smelly.
square(X).
neighbouring(X,wumpus).

smelly(X) :- square(X),neighbouring(X,wumpus).