% All purple mushrooms are poisonous.
% No purple mushroom is poisonous.
% There are exactly two purple mushrooms.
% Clinton is not tall.

mushroom(X).
purple(X).
mushroom(Y).
purple(Y).
mushroom(Z).
purple(Z).
not(tall(clinton)).

poisonous(X) :- mushroom(X),purple(X).
not(poisonous(X)) :- mushroom(X),purple(X).
((X=Z),(Y=Z)) :- mushroom(X),purple(X),mushroom(Y),purple(Y),not(X=Y),mushroom(Z),purple(Z).