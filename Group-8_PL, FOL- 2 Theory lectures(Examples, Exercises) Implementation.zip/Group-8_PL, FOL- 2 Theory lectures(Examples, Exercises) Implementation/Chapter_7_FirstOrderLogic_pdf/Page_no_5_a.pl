% One plus two equals three.
3 is 1+2.