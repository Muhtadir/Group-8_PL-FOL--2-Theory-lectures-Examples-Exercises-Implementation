% (∀x) dolphin(x) => mammal(x).
% (∀x) human(x) => mortal(x)
% (∀x) student(x) => smart(x) (All students are smart).

mammal(X).
human(Y).
smart(Z).

dolphin(X) :- mammal(X).
mortal(Y) :- human(Y).
student(Z) :- smart(Z).